Client
---

# Mobile
Read ios/README.md

# Web
Under realtime_ai_character/static

# Terminal
Under client/cli.py
