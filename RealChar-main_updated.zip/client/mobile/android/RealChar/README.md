# RealChar - Android
![](.assets/android-preview-semi-prototype.gif)