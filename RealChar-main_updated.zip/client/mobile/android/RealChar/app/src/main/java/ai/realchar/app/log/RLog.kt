/**
 * Created by obesitychow on 8/15/23
 */

package ai.realchar.app.log

import android.util.Log

typealias RLog=Log