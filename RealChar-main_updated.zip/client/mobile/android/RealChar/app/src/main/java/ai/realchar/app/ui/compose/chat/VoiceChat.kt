/**
 * Created by obesitychow on 8/22/23
 */

package ai.realchar.app.ui.compose.chat

import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun VoiceChat(modifier: Modifier = Modifier) {
    Box(modifier = modifier) {
        Text("voice mode")
    }
}