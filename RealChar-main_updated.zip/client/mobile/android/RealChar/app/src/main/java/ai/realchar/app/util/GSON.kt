/**
 * Created by obesitychow on 8/17/23
 */

package ai.realchar.app.util

import com.google.gson.Gson


val GSON = Gson()
