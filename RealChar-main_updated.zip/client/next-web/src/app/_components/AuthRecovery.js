
import React, { useState } from 'react'
import { supabase } from '../firebase/config'

export default function AuthRecovery() {
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const handleRecoverAccount = async () => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email })
      if (error) throw error
      const deviceId = data.user.id
      localStorage.setItem('device_id', deviceId)
      setMessage('Account recovered successfully!')
    } catch (error) {
      setMessage(`Error: ${error.message}`)
    }
  }

  return (
    <div>
      <h2>Recover Account</h2>
      <div>
        <input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button onClick={handleRecoverAccount}>Recover Account</button>
      </div>
      {message && <p>{message}</p>}
    </div>
  )
}
