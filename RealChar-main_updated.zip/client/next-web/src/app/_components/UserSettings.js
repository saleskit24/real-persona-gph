
import React, { useState } from 'react'
import { supabase } from '../firebase/config'
import { useAuth } from '../context/AuthContext'

export default function UserSettings() {
  const { user } = useAuth()
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const handleLinkEmail = async () => {
    try {
      const { data, error } = await supabase.auth.updateUser({
        email,
        email_confirm: true,
      })
      if (error) throw error
      setMessage('Email linked successfully!')
    } catch (error) {
      setMessage(`Error: ${error.message}`)
    }
  }

  return (
    <div>
      <h2>User Settings</h2>
      {user ? (
        <div>
          <p>Device ID: {user.id}</p>
          <div>
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <button onClick={handleLinkEmail}>Link Email</button>
          </div>
          {message && <p>{message}</p>}
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  )
}
