
import React, { useState, useRef } from 'react';
import { Button, Input } from '@nextui-org/react';
import WaveSurfer from 'wavesurfer.js';
import { useAppStore } from '@/zustand/store';

export default function ChatInterface() {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [waveformUrl, setWaveformUrl] = useState(null);
  const mediaRecorderRef = useRef(null);
  const waveformRef = useRef(null);
  const videoRef = useRef(null);
  const { handleSendMessage } = useAppStore();

  const handleFileUpload = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleSend = () => {
    if (selectedFile) {
      handleSendMessage({ type: 'file', file: selectedFile });
      setSelectedFile(null);
    } else {
      handleSendMessage({ type: 'text', text: message });
    }
    setMessage('');
  };

  const handleCameraToggle = () => {
    setIsCameraOpen(!isCameraOpen);
  };

  const handleStartRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    videoRef.current.srcObject = stream;
    mediaRecorderRef.current = new MediaRecorder(stream);
    mediaRecorderRef.current.ondataavailable = (event) => {
      setWaveformUrl(URL.createObjectURL(event.data));
    };
    mediaRecorderRef.current.start();
    setIsRecording(true);
  };

  const handleStopRecording = () => {
    mediaRecorderRef.current.stop();
    setIsRecording(false);
  };

  const handleAttachment = () => {
    document.getElementById('file-input').click();
  };

  return (
    <div className="chat-interface">
      <div className="chat-header">
        <Button onPress={handleCameraToggle}>{isCameraOpen ? 'Close Camera' : 'Open Camera'}</Button>
        <Button onPress={handleAttachment}>Attach File</Button>
        <input type="file" id="file-input" onChange={handleFileUpload} style={{ display: 'none' }} />
      </div>
      {isCameraOpen && (
        <div className="camera-view">
          <video ref={videoRef} autoPlay />
          <Button onPress={isRecording ? handleStopRecording : handleStartRecording}>
            {isRecording ? 'Stop Recording' : 'Start Recording'}
          </Button>
        </div>
      )}
      <div className="chat-input">
        <Input
          placeholder="Type your message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <Button onPress={handleSend}>Send</Button>
      </div>
      {waveformUrl && (
        <div className="waveform-view">
          <WaveSurfer
            ref={waveformRef}
            url={waveformUrl}
            waveColor="violet"
            progressColor="purple"
            cursorWidth={1}
            cursorColor="navy"
            height={128}
          />
        </div>
      )}
    </div>
  );
}
