
import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@nextui-org/react';
import WaveSurfer from 'wavesurfer.js';

export default function AIResponse({ audioUrl }) {
  const waveformRef = useRef(null);
  const audioRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    waveformRef.current = WaveSurfer.create({
      container: '#waveform-ai',
      waveColor: 'blue',
      progressColor: 'cyan',
      cursorWidth: 1,
      cursorColor: 'navy',
      height: 200,
    });

    waveformRef.current.load(audioUrl);

    audioRef.current = new Audio(audioUrl);
    audioRef.current.onended = () => {
      setIsPlaying(false);
    };

    return () => {
      waveformRef.current.destroy();
    };
  }, [audioUrl]);

  const handlePlayPause = () => {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleStopAI = () => {
    audioRef.current.pause();
    setIsPlaying(false);
  };

  return (
    <div className="flex flex-col items-center gap-2">
      <div id="waveform-ai" className="w-full"></div>
      <Button onPress={handlePlayPause} className="bg-real-contrastBlue">
        {isPlaying ? 'Pause' : 'Play'}
      </Button>
      <Button onPress={handleStopAI} className="bg-red-500">
        Stop AI
      </Button>
    </div>
  );
}
