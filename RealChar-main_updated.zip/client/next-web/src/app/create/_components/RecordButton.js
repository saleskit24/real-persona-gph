
import React, { useState, useEffect, useRef } from 'react';
import { Button, Select, SelectItem } from '@nextui-org/react';
import { useAppStore } from '@/zustand/store';
import WaveSurfer from 'wavesurfer.js';

export default function RecordButton() {
  const [isRecording, setIsRecording] = useState(false);
  const [selectedService, setSelectedService] = useState('deepgram');
  const [language, setLanguage] = useState('en-US');
  const waveformRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioContextRef = useRef(null);
  const audioInputRef = useRef(null);
  const analyserRef = useRef(null);
  const dataArrayRef = useRef(null);
  const animationIdRef = useRef(null);
  const { handleTranscription } = useAppStore();

  useEffect(() => {
    if (isRecording) {
      startRecording();
    } else {
      stopRecording();
    }
  }, [isRecording]);

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
    audioInputRef.current = audioContextRef.current.createMediaStreamSource(stream);
    analyserRef.current = audioContextRef.current.createAnalyser();
    audioInputRef.current.connect(analyserRef.current);
    analyserRef.current.fftSize = 2048;
    const bufferLength = analyserRef.current.frequencyBinCount;
    dataArrayRef.current = new Uint8Array(bufferLength);

    waveformRef.current = WaveSurfer.create({
      container: '#waveform',
      waveColor: 'violet',
      progressColor: 'purple',
      cursorWidth: 1,
      cursorColor: 'navy',
      height: 128,
    });

    drawWaveform();

    mediaRecorderRef.current = new MediaRecorder(stream);
    mediaRecorderRef.current.ondataavailable = async (event) => {
      const audioBlob = new Blob([event.data], { type: 'audio/wav' });
      const audioFile = new File([audioBlob], 'audio.wav', { type: 'audio/wav' });

      if (selectedService === 'deepgram') {
        await transcribeWithDeepgram(audioFile);
      } else if (selectedService === 'assemblyai') {
        await transcribeWithAssemblyAI(audioFile);
      }
    };
    mediaRecorderRef.current.start();
  };

  const stopRecording = () => {
    mediaRecorderRef.current.stop();
    cancelAnimationFrame(animationIdRef.current);
    waveformRef.current.destroy();
  };

  const drawWaveform = () => {
    analyserRef.current.getByteTimeDomainData(dataArrayRef.current);
    waveformRef.current.loadBlob(new Blob([dataArrayRef.current], { type: 'audio/wav' }));
    animationIdRef.current = requestAnimationFrame(drawWaveform);
  };

  const transcribeWithDeepgram = async (audioFile) => {
    const response = await fetch('https://api.deepgram.com/v1/listen', {
      method: 'POST',
      headers: {
        'Authorization': `Token ${process.env.DEEPGRAM_API_KEY}`,
        'Content-Type': 'audio/wav',
      },
      body: audioFile,
    });
    const data = await response.json();
    handleTranscription(data.results.channels[0].alternatives[0].transcript);
  };

  const transcribeWithAssemblyAI = async (audioFile) => {
    const response = await fetch('https://api.assemblyai.com/v2/transcript', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.ASSEMBLYAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        audio_url: URL.createObjectURL(audioFile),
        language_code: language,
      }),
    });
    const data = await response.json();
    handleTranscription(data.text);
  };

  return (
    <div className="flex flex-col items-center gap-2">
      <Select
        placeholder="Select Language"
        value={language}
        onChange={(e) => setLanguage(e.target.value)}
      >
        <SelectItem value="en-US">English (US)</SelectItem>
        <SelectItem value="es">Spanish</SelectItem>
        <SelectItem value="fr">French</SelectItem>
        <SelectItem value="de">German</SelectItem>
        <SelectItem value="tl">Tagalog</SelectItem>
        {/* Add more language options as needed */}
      </Select>
      <Select
        placeholder="Select Service"
        value={selectedService}
        onChange={(e) => setSelectedService(e.target.value)}
      >
        <SelectItem value="deepgram">Deepgram.ai</SelectItem>
        <SelectItem value="assemblyai">Assembly.ai</SelectItem>
      </Select>
      <Button onPress={() => setIsRecording(!isRecording)} className="bg-real-contrastBlue">
        {isRecording ? 'Stop Recording' : 'Start Recording'}
      </Button>
      <div id="waveform" className="w-full"></div>
    </div>
  );
}
