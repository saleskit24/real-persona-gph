
import React, { useEffect, useRef } from 'react';
import { Button } from '@nextui-org/react';
import WaveSurfer from 'wavesurfer.js';
import { useAppStore } from '@/zustand/store';

export default function AIResponse() {
  const waveformRef = useRef(null);
  const audioContextRef = useRef(null);
  const audioInputRef = useRef(null);
  const analyserRef = useRef(null);
  const dataArrayRef = useRef(null);
  const animationIdRef = useRef(null);
  const { aiSpeaking, setAISpeaking } = useAppStore();

  useEffect(() => {
    if (aiSpeaking) {
      startWaveform();
    } else {
      stopWaveform();
    }
  }, [aiSpeaking]);

  const startWaveform = async () => {
    audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
    analyserRef.current = audioContextRef.current.createAnalyser();
    analyserRef.current.fftSize = 2048;
    const bufferLength = analyserRef.current.frequencyBinCount;
    dataArrayRef.current = new Uint8Array(bufferLength);

    waveformRef.current = WaveSurfer.create({
      container: '#ai-waveform',
      waveColor: 'blue',
      progressColor: 'navy',
      cursorWidth: 1,
      cursorColor: 'blue',
      height: 256,
    });

    drawWaveform();
  };

  const stopWaveform = () => {
    cancelAnimationFrame(animationIdRef.current);
    waveformRef.current.destroy();
  };

  const drawWaveform = () => {
    analyserRef.current.getByteTimeDomainData(dataArrayRef.current);
    waveformRef.current.loadBlob(new Blob([dataArrayRef.current], { type: 'audio/wav' }));
    animationIdRef.current = requestAnimationFrame(drawWaveform);
  };

  const handleStopAI = () => {
    setAISpeaking(false);
    stopWaveform();
  };

  return (
    <div className="flex flex-col items-center gap-2">
      <Button onPress={handleStopAI} className="bg-real-contrastBlue">
        Stop AI
      </Button>
      <div id="ai-waveform" className="w-full"></div>
    </div>
  );
}
