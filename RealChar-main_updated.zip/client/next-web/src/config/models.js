
const models = [
  { name: 'GPT-3.5', value: 'gpt-3.5-turbo' },
  { name: 'GPT-4.0', value: 'gpt-4' },
  { name: 'GPT-4 Omni', value: 'gpt-4-omni' },
  { name: 'GPT-4 Omni Preview', value: 'gpt-4-omni-preview' },
  // Add other models as needed
];

export default models;
