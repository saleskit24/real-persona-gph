
import React, { createContext, useContext, useEffect, useState } from 'react'
import { getDeviceId } from '../utils/device'

const AuthContext = createContext()

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)

  useEffect(() => {
    const deviceId = getDeviceId()
    // Fetch or create user based on device ID
    async function fetchUser() {
      // Replace this with your actual fetch logic
      const userData = await fetchUserByDeviceId(deviceId)
      setUser(userData)
    }
    fetchUser()
  }, [])

  return (
    <AuthContext.Provider value={{ user }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}

// Dummy function to simulate fetching user data by device ID
async function fetchUserByDeviceId(deviceId) {
  // Replace this with actual API call or logic to fetch user data by device ID
  return { id: deviceId, name: 'Test User' }
}
