
export function getDeviceId() {
  // Generate a unique device ID (for demonstration purposes)
  // In a real-world scenario, this might involve more complex logic
  const deviceId = localStorage.getItem('device_id') || generateUniqueId()
  localStorage.setItem('device_id', deviceId)
  return deviceId
}

function generateUniqueId() {
  return 'xxxx-xxxx-xxxx-xxxx'.replace(/x/g, () => {
    return Math.floor(Math.random() * 16).toString(16)
  })
}
